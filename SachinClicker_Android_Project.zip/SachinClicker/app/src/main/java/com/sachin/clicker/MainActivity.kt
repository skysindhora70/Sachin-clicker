package com.sachin.clicker

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("sachin_clicker", MODE_PRIVATE) }
    private lateinit var pickupInput: EditText
    private lateinit var dropInput: EditText
    private lateinit var pickupTest: EditText
    private lateinit var dropTest: EditText
    private lateinit var result: TextView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            setBackgroundColor(Color.rgb(245, 247, 251))
        }
        scroll.addView(page)

        val title = TextView(this).apply {
            text = "SACHIN CLICKER"
            textSize = 26f
            setTextColor(Color.rgb(20, 55, 105))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 6)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        page.addView(title)
        page.addView(label("Smart Ride Distance Matcher — Offline"))

        page.addView(sectionTitle("AUTOMATION SETTINGS"))
        pickupInput = numberField("Maximum Pickup Distance (KM)", prefs.getFloat("pickup_limit", 2f).toString())
        dropInput = numberField("Maximum Drop Distance (KM)", prefs.getFloat("drop_limit", 12f).toString())
        page.addView(pickupInput)
        page.addView(dropInput)

        val apply = button("APPLY CHANGES")
        page.addView(apply)
        apply.setOnClickListener { saveSettings() }

        status = label("Status: Settings ready")
        status.setTextColor(Color.rgb(30, 120, 75))
        page.addView(status)

        page.addView(sectionTitle("TEST RIDE DISTANCE"))
        pickupTest = numberField("Test Pickup Distance (KM)", "1.5")
        dropTest = numberField("Test Drop Distance (KM)", "10")
        page.addView(pickupTest)
        page.addView(dropTest)

        val test = button("CHECK RIDE MATCH")
        page.addView(test)
        test.setOnClickListener { checkRide() }

        result = TextView(this).apply {
            text = "Enter test distances and tap Check Ride Match."
            textSize = 17f
            setTextColor(Color.DKGRAY)
            setPadding(12, 20, 12, 20)
        }
        page.addView(result)

        val note = TextView(this).apply {
            text = "Note: This version only saves your KM limits and tests ride matching locally. It does not read or control Rapido or any other third-party app, and it does not automatically accept or book rides."
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(4, 18, 4, 8)
        }
        page.addView(note)
        setContentView(scroll)
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 14f
        setTextColor(Color.DKGRAY)
        setPadding(4, 4, 4, 12)
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 16f
        setTextColor(Color.rgb(20, 55, 105))
        setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(4, 24, 4, 8)
    }

    private fun numberField(hintText: String, value: String): EditText {
        return EditText(this).apply {
            hint = hintText
            setText(value)
            textSize = 16f
            inputType = InputType.TYPE_CLASS_NUMBER or
                InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            setPadding(14, 12, 14, 12)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = 18f
                setStroke(1, Color.LTGRAY)
            }
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(0, 7, 0, 7)
            layoutParams = params
        }
    }

    private fun button(value: String) = Button(this).apply {
        text = value
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(25, 105, 190))
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(0, 14, 0, 8)
        layoutParams = params
    }

    private fun parsePositive(field: EditText, fieldName: String): Double? {
        val value = field.text.toString().trim().toDoubleOrNull()
        if (value == null || value <= 0.0) {
            Toast.makeText(this, "Enter a valid $fieldName greater than 0", Toast.LENGTH_LONG).show()
            return null
        }
        return value
    }

    private fun saveSettings() {
        val pickup = parsePositive(pickupInput, "pickup limit") ?: return
        val drop = parsePositive(dropInput, "drop limit") ?: return
        prefs.edit()
            .putFloat("pickup_limit", pickup.toFloat())
            .putFloat("drop_limit", drop.toFloat())
            .apply()
        status.text = "Status: Saved — Pickup ≤ ${pickup} KM, Drop ≤ ${drop} KM"
        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
    }

    private fun checkRide() {
        val maxPickup = prefs.getFloat("pickup_limit", 2f).toDouble()
        val maxDrop = prefs.getFloat("drop_limit", 12f).toDouble()
        val pickup = parsePositive(pickupTest, "test pickup distance") ?: return
        val drop = parsePositive(dropTest, "test drop distance") ?: return
        val matches = pickup <= maxPickup && drop <= maxDrop
        result.text = if (matches) {
            "MATCH ✓\nPickup: $pickup KM (limit $maxPickup KM)\nDrop: $drop KM (limit $maxDrop KM)"
        } else {
            "NO MATCH ✕\nPickup: $pickup KM (limit $maxPickup KM)\nDrop: $drop KM (limit $maxDrop KM)"
        }
        result.setTextColor(if (matches) Color.rgb(20, 130, 75) else Color.rgb(190, 55, 55))
    }
}
