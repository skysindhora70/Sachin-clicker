# Sachin Clicker — Android Project

यह शुरुआती संस्करण आपके द्वारा चुनी गई Maximum Pickup और Maximum Drop दूरी सेव करता है और उदाहरण वाली Ride दूरी पर MATCH / NO MATCH दिखाता है।

## Android फोन से APK बनाने का तरीका (GitHub Actions)

1. ZIP को फोन में डाउनलोड करके Extract करें।
2. GitHub ऐप या Chrome में github.com खोलें और लॉगिन करें।
3. `+` दबाकर **New repository** चुनें।
4. Repository name `SachinClicker` रखें और Public या Private चुनकर Create करें।
5. Repository में **Add file → Upload files** चुनें।
6. ZIP को पहले Extract करें। Extract किए हुए `SachinClicker` फोल्डर के अंदर की सभी फाइलें/फोल्डर अपलोड करें। ZIP फाइल को अकेले अपलोड न करें।
7. Commit changes करें। अपलोड में `.github/workflows/build-apk.yml` भी शामिल होना चाहिए।
8. Repository के **Actions** टैब में जाएँ। `Build Sachin Clicker APK` workflow खुलना चाहिए।
9. चल रहे build पर टैप करें। सफल होने पर नीचे **Artifacts** में `Sachin-Clicker-debug-apk` डाउनलोड करें।
10. डाउनलोड की ZIP खोलें और `app-debug.apk` इंस्टॉल करें। Android पूछे तो केवल इसी डाउनलोड की गई APK के लिए install permission दें।

## ऐप क्या करता है
- Pickup और Drop की maximum KM सीमा सेव करता है।
- Decimal दूरी स्वीकार करता है, जैसे 1.5 या 1.8 KM।
- दोनों शर्तें पूरी होने पर MATCH दिखाता है।
- सेटिंग फोन में सेव रहती है।

## जरूरी सीमा
यह ऐप अभी किसी third-party ride app की स्क्रीन नहीं पढ़ता और ride accept/book नहीं करता। यह केवल स्वतंत्र offline distance-matching calculator है।
